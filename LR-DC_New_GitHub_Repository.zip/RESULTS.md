## Test map

### Analytically established

- conserved three-scalar current
- cold homogeneous branch
- spherical reduction
- r^-2 similarity solution and flat-Vc consequence
- phase-space representation
- outer separatrix mathematics
- standard-GR lensing formulas

### Numerically supported

- SPARC 175-galaxy calibration
- DDO 161 diagnostic
- corrected N-body similarity over tested seeds
- multistream formation in cold-sheet tests
- compressed CMB/background checks
- early-universe estimates
- strong local scale separation of the collective filter

### Unknown

- full TT/TE/EE Boltzmann spectra
- CMB lensing reconstruction
- Bullet Cluster / merger simulation
- complete PPN / solar-system audit
- full nonlinear Einstein-DC stability
- microscopic derivation of W_IR
- first-principles alpha_IR and chi_form
- fully relaxed phase-space normalization
- derived diffuse dark-energy branch

## Development rule

**derive -> solve -> compare -> calibrate only where justified -> re-test**

The goal is to make every empirical input traceable and every unresolved prediction explicit.
